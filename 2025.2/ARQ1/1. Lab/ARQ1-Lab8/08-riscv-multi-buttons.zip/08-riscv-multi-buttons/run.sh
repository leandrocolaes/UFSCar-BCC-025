./tests/run.sh fibo
