sudo apt update && sudo apt install iverilog gcc-riscv64-unknown-elf binutils-riscv64-unknown-elf
